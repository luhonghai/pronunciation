//
//  UserProfile.swift
//  AccentEasy
//
//  Created by CMGVN on 1/15/16.
//  Copyright © 2016 Hoang Nguyen. All rights reserved.
//

import Foundation

public class UserProfile {
    public let HELP_INIT:Int = 0;
    public let HELP_SKIP:Int = 1;
    public let HELP_NEVER:Int = 2;
    
    
    public var username:String!
    public var firstName:String!
    public var lastName:String!
    public var name:String!
    public var loginType:String!
    public var profileImage:String!
    public var password:String!
    public var isSetup:Bool = false;
    public var nativeEnglish:Bool = true
    public var gender:Bool = true
    public var dob:String = "01/01/1900";
    public var country:String = "GB";
    public var englishProficiency:Int = 5
    public var time:CLong!
    public var duration:CLong!
    public var location:UserLocation!
    public var deviceInfo:DeviceInfo!
    public var uuid:String!
    //public var helpStatus:HELP_INIT!
    public var isLogin:Bool = false
    public var lastSelectedMenuItem:String!
    public var licenseCode:String!
    //public var selectedCountry:Country!
    public var token:String!
    public var additionalToken:String!
    public var isActivatedLicence:Bool!
    /*public var password:String!
    public var password:String!
    public var password:String!
    public var password:String!
    public var password:String!*/
    
    /*private String ;
    private UserLocation ;
    private DeviceInfo ;
    private String ;
    private int  = ;
    private boolean  = false;
    private String ;
    
    private String ;
    
    private  ;
    
    private String ;
    
    private String ;
    
    private boolean ;
    
    private boolean isSubscription;
    
    private boolean isExpired;
    
    private List<LicenseData> licenseData;*/
    
    public class UserLocation {
        private var latitude:Double!
        private var longitude:Double!
        
    }
    
    public class DeviceInfo {
        private var appVersion:String!
        private var appName:String!
        private var model:String!
        private var osVersion:String!
        private var osApiLevel:String!
        private var deviceName:String!
        private var emei:String!
        private var gcmId:String!
        
    }
    
    
    
    
    public var Username:String {
        get {
            return username
        }
        set(newValue) {
            username = newValue
        }
    }
    

}
